function [flag_y]=feasible_test(xin,level)
%Given X's submatrix, test the feasiblity of the corresponding subproblem  
global Nt Nr   N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up   Tmax H  ;
% Xin==>X
X=zeros(level-1,N_BS+1); 
for i=1:level-1%assign the first "level-1" rows 
    for j=1:N_BS+1
        if j==xin(i)
            X(i,j)=1;
        else
            X(i,j)=0;
        end
    end
end
% [a b]=size(X);
a=level-1;
 R_bar=zeros(a,N_BS);
 bw_Min=zeros(a,N_BS);
 %generate optimal Q��compute maximum R_bar, and minimum bandwidth, bw_min
for i=1:a
       Q(:,:,i)=zeros(Nt,Nt);
    for j=1:N_BS 
       if X(i,j+1)==1 
           Q(:,:,i)=water_fill_Qopt(H(:,:,i,j),Pt,noise);
       end
    end
end
for i=1:a
    for j=1:N_BS
        if X(i,j+1)==1
          R_bar(i,j)=X(i,j+1)*log2(det(eye(Nr,Nr) + H(:,:,i,j) * Q(:,:,i) *(H(:,:,i,j))'/noise)) ;
          bw_Min(i,j)=X(i,j+1)*b_up*L(i)/R_bar(i,j)/(Tmax-a_exe*L(i)/(f_MEC *1000)); 
        end
    end 
end
%-------------------Test the feasbility via two conditions--------------------------------
%Condition 1��bandwidth
for j=1:N_BS
    if sum(bw_Min(:,j)) > B(j) 
         flag_y=0; 
         return;
    end
end

%Condition 1��latency
f=f_Lmax ; 
bw=zeros(a,N_BS);  
T_user=zeros(a,1);  
%1��  generate bw
 bw = bw_Min;  
%2��  compute each user's latency
for i=1:a
    T_user(i)=  X(i,1)*a_exe*L(i)/(f(i)*1000);
  for j=2:N_BS+1
      if X(i,j)==1
         T_user(i)=T_user(i) + X(i,j)*(b_up*L(i)/bw(i,j-1)/R_bar(i,j-1) + a_exe*L(i)/(f_MEC *1000));
      end
  end
end
%3�� test the feasibility
if max(T_user)<=Tmax + 1e-6    
    flag_y=1;
else 
    flag_y=0;  
end  