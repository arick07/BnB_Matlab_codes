function sequ=user_sort(lambda1,lambda2,flag)
%This procedure sorts users according to their costs, and update H��L, and f_Lmax according the new ordering
%flag=1 --descend��0 --ascend
 global Nt Nr N_user N_BS     f_Lmax L H  ;
 %1 compute all user choices' costs  
 for i=1:N_user
     for j=1:N_BS+1
         X=zeros(N_user,N_BS+1);
         X(i,j)=1;
         Obj_F(i,j)=F_actual(X,lambda1,lambda2);
     end
 end
 %2 compute each user's cost
 Cost_user=sum(Obj_F,2);
 %3 Sorting and update H��L, and f_Lmax
 H_new=zeros(Nr,Nt,N_user,N_BS);
 L_new=zeros(N_user,1);
 f_Lmax_new=zeros(N_user,1);
 if flag==1
      [a b]=sort(Cost_user,'descend');
 else
      [a b]=sort(Cost_user,'ascend');
 end
 for i=1:N_user
     for j=1:N_BS
       H_new(:,:,i,j)=H(:,:,b(i),j);
     end
     L_new(i)=L(b(i));
     f_Lmax_new(i)=f_Lmax(b(i));
 end
 H=H_new; L=L_new;
 f_Lmax=f_Lmax_new;
 sequ=b;