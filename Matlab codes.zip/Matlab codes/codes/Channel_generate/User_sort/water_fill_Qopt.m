function Qopt=water_fill_Qopt(H,Pt,noise)
%given H and Pt, solve the transmission covarance matrix Qopt

[U ,lamda , V1]=svd(H); 
lamda=lamda.^2/noise;
Q=water_filling(lamda,Pt); 
Qopt=V1*diag(Q)*V1'; 