function [Obj_Cal]=F_actual(X,lambda1,lambda2)
global  Nr N_user N_BS  Pt L B H noise a_exe b_up k0 Tmax f_Lmax f_MEC; 
%--find X's nonzero entry (only one entry)--
for i=1:N_user
    for j=1:N_BS+1
        if X(i,j)==1
            i0=i;j0=j;
        end
    end
end
if j0==1 %Local  compute
 %Method 1: use formula directly
 f0=(lambda1/lambda2/2/k0)^(1/3); %unit: GHz
 if f0>f_Lmax(i0)
     f_OPT=f_Lmax(i0);
 elseif f0<a_exe*L(i0)/Tmax
     f_OPT=a_exe*L(i0)/Tmax;
 else
     f_OPT=f0;
 end
  Obj_Cal=lambda1*a_exe*L(i0)/f_OPT/1000 + lambda2*k0*f_OPT^2*a_exe*L(i0)*1e6;
  Qy=[];fy=f_OPT; 
  return;
end

%--otherwise, use MEC----
%M1��1D search method (Appendix A)
Obj_Cal=search_1D(i0,j0,lambda1,lambda2)   ;