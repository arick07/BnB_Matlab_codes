function Q=water_filling(lamda,P)
%Adopt water-filling method to solve the optimal power allocation matrix (vector form)
%input: lamda (diagonal or vector form)
%output: vector form 
tmp=size(lamda);
if tmp(1)==tmp(2)&tmp(1)~=1
    lamda=diag(lamda);%diagonal to vector form
end
lamda_ordered=sort(lamda,'descend');%desend
len=length(lamda);
lamda_ordered_cut_zero=zeros(1,len);
len_cut=0;
for i=1:len
    if lamda_ordered(i)>0
    lamda_ordered_cut_zero(i)=lamda_ordered(i);
    len_cut=len_cut+1;
    end
end
%len_cut=length(lamda_ordered_cut_zero);
%solve u;
u=-1;
for iter=0:len_cut-1
    u=(P+sum(1./lamda_ordered_cut_zero(1:len_cut-iter)))/(len_cut-iter);
    %test u
    if(min(u-1./lamda_ordered_cut_zero(1:len_cut-iter))>0)
        break;
    end
end% for
%obtain Q[];
Q=max(u-1./lamda,0);% the output accords to lamda
    
    
