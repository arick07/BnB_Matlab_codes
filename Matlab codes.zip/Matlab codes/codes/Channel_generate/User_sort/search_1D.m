function Obj_cal=search_1D(i0,j0,lambda1,lambda2) 
 global   Nr   Pt   f_MEC B noise L a_exe b_up   Tmax H  ; 
%1 find the min power with bisection method 
% use the following formula:
% Tmax >= b_up * L(i0)*pow_p(R_bar,-1) + a_exe* L(i0)*pow_p(f_MEC,-1) /1000
% -->  Tmax - a_exe* L(i0)/f_MEC/1000 >= b_up * L(i0)/R_bar;
% -->  R_bar >= b_up * L(i0)/(Tmax- a_exe* L(i0)/f_MEC/1000);
R_bar_min = b_up * L(i0)/(Tmax- a_exe* L(i0)/f_MEC/1000); 
Q  = water_fill_Qopt(H(:,:,i0,j0-1),Pt,noise);
R_bar = B(j0-1)*log2(det(eye(Nr,Nr) + H(:,:,i0,j0-1)*Q*(H(:,:,i0,j0-1))'/noise)); 
R_bar=real(R_bar);
if R_bar<R_bar_min
    Obj_cal=Inf;%infeasible
    return;
end
%---begin---
epsilon=1e-3;
flag=1;
P_s=0;P_d=Pt;
while(flag) 
P_mid=(P_s+P_d)/2;
Q  = water_fill_Qopt(H(:,:,i0,j0-1),P_mid,noise);
R_bar = B(j0-1)*log2(det(eye(Nr,Nr) + H(:,:,i0,j0-1)*Q*(H(:,:,i0,j0-1))'/noise)); 
R_bar=real(R_bar);
if  R_bar>R_bar_min
    P_d=P_mid;
else
    P_s=P_mid;
end
   if P_d-P_s < epsilon
       flag=0;
   end
end
Pt_min=real(trace(Q));

%2 search the power trace(Q��, within [Pt_min,Pt], and find min F
% F=lambda1* [b_up * L(i0)*pow_p(R_bar,-1) + a_exe* L(i0)*pow_p(f_MEC,-1) /1000]
% +lambda2*[b_up * L(i)*trace(Q)/R_bar];
P_s=Pt_min;P_d=Pt; 
Nsam=20;
step=(-P_s+P_d)/Nsam;
for i=0:Nsam  
    Q  = water_fill_Qopt(H(:,:,i0,j0-1), P_s+i*step,noise);
    R_bar = B(j0-1)* real(log2(det(eye(Nr,Nr) + H(:,:,i0,j0-1)*Q*(H(:,:,i0,j0-1))'/noise))); 
    F(i+1)=lambda1* (b_up * L(i0)/R_bar + a_exe* L(i0)/f_MEC/1000) ...
         + lambda2*b_up * L(i0)*real(trace(Q))/R_bar;
end 
[Obj_cal id]=min(F);
P_s+id*step;