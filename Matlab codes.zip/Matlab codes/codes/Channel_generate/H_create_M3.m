function H=H_create_M3(fseed,N)
%generate channel H (N*N) 
% fseed=0; 
% N=4;
randn('seed',fseed);
X=0.707*randn(1,N*N) + 0.707*1i*randn(1,N*N); 
H=zeros(N,N);
index=1;
for i=1:N
    for j=1:i
        H(i,j)=X(index);
        index=index+1;
        if i>j
          H(j,i)=X(index);
          index=index+1;
        end
    end
end 

