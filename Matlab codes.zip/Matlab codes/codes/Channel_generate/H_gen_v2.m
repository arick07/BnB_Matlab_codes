function H_gen_v2(s1,s2,fseed_in)
global Nt Nr N_user N_BS H L f_Lmax;
global  lambda1 lambda2;
%this proc generate a channel sample.
%Parameter s1:M1 M2 M3  --three methods of generating channels
% M1 --random
% M2  --a special kind
% M3 -- another kind
%Parameter s2: ascend  descend  random  no --four sorting rules  

 if nargin == 3  
     fseed0=fseed_in;
 else
     fseed0=0;
 end 
%Step 1������Hw 
H=zeros(Nr,Nt,N_user,N_BS);
if strcmp(s1,'M1')==1
    %M1��randomly generate
    randn('seed',fseed0);
    H=0.707*randn(Nr,Nt,N_user,N_BS)+0.707*1i*randn(Nr,Nt,N_user,N_BS);
elseif  strcmp(s1,'M2')==1
    %M2�� 
    for i=1:N_user
        randn('seed',i+fseed0);
        for j=1:N_BS
        H(:,:,i,j)=0.707*randn(Nr,Nt)+0.707*1i*randn(Nr,Nt);
        end
    end
else
    %M3�� 
    for i=1:N_user 
        for j=1:N_BS 
          fseed=100*i+j+fseed0;
          H(:,:,i,j)=H_create_M3(fseed,Nt);
        end
    end 
end
%Step 2: other settings
d=100;%distance unit: m
H=H*(1e-1)/d^2; 
H(:,:,1,:)=H(:,:,1,:)/6.25;  

%Step 3�� -----user sorting----
%Note: we must update H��L, and f_Lmax according to the new order.
if strcmp(s2,'descend')==1 %OPT
    cd ./User_sort;
    sequ=user_sort(lambda1, lambda2,1)
    cd ..
elseif strcmp(s2,'ascend')==1 %Worst
    cd ./User_sort;
    sequ=user_sort(lambda1, lambda2,0)
    cd ..
elseif strcmp(s2,'random')==1 %random 
    for j=1:N_BS
        Ht=H(:,:,1,j);H(:,:,1,j)=H(:,:,N_user,j);H(:,:,N_user,j)=Ht; 
    end
    Lt=L(1);L(1)=L(N_user);L(N_user)=Lt; 
    ft=f_Lmax(1);f_Lmax(1)=f_Lmax(N_user);f_Lmax(N_user)=ft;  
else %no change
    ;
end
 

