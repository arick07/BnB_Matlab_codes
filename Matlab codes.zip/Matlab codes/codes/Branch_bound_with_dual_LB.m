function [node_num]=Branch_bound_with_dual_LB(H_i,lambda1,lambda2 )
global  N_user N_BS Nr Nt Pt  k0 f_Lmax  L a_exe Vopt  Node_id_cur ; 
global node; 
% Node state��
% -3--infeasible��-2--feasible, no need branch��-1--can not branch��-10--have been branched��1--feasible, and can branch
% Solve_P_LB.m
% flag��-1--infeasible��1--feasible, can branch��0--feasible, can not branch��

N_inf_count=0; 
level_Max=N_user+1; 
Xopt=zeros(N_user,N_BS+1);
Epson = 1e-2;
 % ----find a feasible solution--- 
[Xopt,Q,f,bw,flag_y]=feasible_gen();
[Vopt.v, E, T]=E_T_Cal(Xopt,Q,f,bw); 
Vopt.X=Xopt;Vopt.f=f;
Vopt.Q=Q;Vopt.bw=bw; 
%-------------------------------- 
%----make the first node, i.e. the root node--- 
node(1).father=-1;
node(1).level=1; 
node(1).x=[]; 
   cd ./Solve_P_LB_and_update(by_dual_method)
   [y1  flag]=Solve_P_LB(node(1).x, node(1).level );
   cd .. 
 if flag==0 %fesibel��no need branch
    node(1).status=-2;
    node(1).LB=y1; 
elseif flag==1%feasibel, can branch
    node(1).status=1;
    node(1).LB=y1; 
else  %flag==-1   infeasible
    node(1).status=-3;
    node(1).LB=Inf;
end

%========Begin========
flag_out=1; 
len_node=1;%the number of all created nodes currently
index=1;
while(flag_out)       
    index=index+1;
   % Step 1: find the node with minimum LB, branch, and solve it 
   flag_in=0;%the indicator of wheter there is a branchable node
   tmp=1000; id_min=0;
    for i=1:len_node
        if node(i).status==1  & node(i).level<level_Max & node(i).LB<tmp %find a branchable node
            flag_in=1; 
            tmp=node(i).LB;
            id_min=i;
        end
    end    
    % Step 2: if find it, branch N_BS+1 nodes, calculate their optimum
    % values and states, update current Vopt and Xopt.
    % Outer loop termination condition 1
    if flag_in==0
        flagout=0;
        break;
    else %flag_in==1 find the branchable node
    % Outer loop termination condition 2
        if  abs(node(id_min).LB-Vopt.v)/Vopt.v <Epson 
            flagout=0;
            break; 
        end
              
 %Key steps��------begin to branch, fathom, and updation--------------
    node(id_min).status=-10; 
    fprintf('\n==== The currently chosen node info��id_min=%d, LB: %.4f, level: %d��Vopt: %.4f.====\n',id_min,node(id_min).LB,node(id_min).level,Vopt.v);
    for j=1:N_BS+1
        %1 the information for the created node
        node(len_node+j).father=id_min;
        node(len_node+j).x=[node(id_min).x j];
        node(len_node+j).level=node(id_min).level+1;
        %2 solve the current node   
         Node_id_cur =len_node+j; 
         %2.1 test the feasibility 
         [flag_tmp]=feasible_test(node(len_node+j).x,node(len_node+j).level);
         if flag_tmp==0 %infeasible
            node(len_node+j).status=-3;
            node(len_node+j).LB=Inf;
            N_inf_count=N_inf_count+1;
         else%if fesible, solve the lower bound
            cd ./Solve_P_LB_and_update(by_dual_method)
             [y1, flag]=Solve_P_LB(node(len_node+j).x, node(len_node+j).level);  
            cd ..
            node(len_node+j).LB=y1; 
         %2.2 determine the states of nodes 
             if flag==0 %fesible��but no need to branch
                node(len_node+j).status=-2; 
                % fathoming
                for i2=1:len_node+j-1
                   if node(i2).status==1 & node(i2).LB>= Vopt.v
                       node(i2).status=-1;
                   end
                end    
            else %flag==1    
                    node(len_node+j).status=1; 
            end%if_flag
         end
      %3 dispaly the created node information  
        fprintf('--create a new node: ID=%d, its father node ID: %d, its Lower bound: %.4f, state: %d--\n',len_node+j, node(len_node+j).father, ...
            node(len_node+j).LB,node(len_node+j).status);
    end%for_j=1:N_BS+1

    %4 update created nodes' number 
    len_node=len_node+N_BS+1; 
  end
end%while
 node_num=len_node;