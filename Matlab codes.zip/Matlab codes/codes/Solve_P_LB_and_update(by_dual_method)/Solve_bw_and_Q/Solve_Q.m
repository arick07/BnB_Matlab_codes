function y_Q=Solve_Q(A,B,C,Hx)
global     noise Pt;
% given A B C, solve Q;  
% solve min F=[A+B*trace(Q)]/R(Q) + C*trace(Q)  
%          s.t. Q is semidefinite
% where R(Q)=log_det(I+HQH'/noise)=log_det(I+H'HQ/noise)  

[U_H lambda]=eig(Hx'*Hx/noise); 
lambda=diag(lambda); 

Pt_max=2*Pt;
Pt_ini=0.01; 
a=Pt_ini;b=Pt_max;eps=0.02;
% ---input
 % fun  objective
 % a     lB
 % b     UB
 % eps    min length
 % ---output
 % xmin 
 
 x1 = a+0.382*(b-a);
 x2 = a +0.618*(b-a);
 %slove f1 f2
 [y,py,u0]=water_filling_for_Q(lambda,x1);
 y =y /log(2);%log function base change: e-->2
 f1=(A+B*x1)/y  + C*x1;
 [y,py,u0]=water_filling_for_Q(lambda,x2);
 y =y /log(2); 
 f2=(A+B*x2)/y  + C*x2; 

%----------begin---------
 while abs(b-a)>eps
     if f1>f2
         a = x1;
         x1 = x2;
         x2 = a +0.618*(b-a);
         f1 = f2;
         %---find new f2---- 
         [y,py,u0]=water_filling_for_Q(lambda,x2);
         y =y /log(2); 
         f2=(A+B*x2)/y  + C*x2;
     else
         b = x2;
         x2 = x1;
         x1 = a+0.382*(b-a);
         f2 = f1;
          %---find new f1---- 
         [y,py,u0]=water_filling_for_Q(lambda,x1);
         y =y /log(2); 
         f1=(A+B*x1)/y  + C*x1;
     end
 end
 xmin=(a+b)/2;
%  fmin = fun(xmin);  

%---solve optimal Pt--- 
Ptx_opt=xmin; 
%----solve optimal py and Q---
[y,py,u0]=water_filling_for_Q(lambda,Ptx_opt);
y_Q=U_H*diag(py)*U_H';

 
