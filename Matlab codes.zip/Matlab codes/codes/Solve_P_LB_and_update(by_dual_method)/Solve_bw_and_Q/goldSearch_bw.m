 function [fmin,xmin,Q_opt,Du_T3,Du_Q] = goldSearch_bw(a,b,i,j0,u_T3,u_Q,u_f,u_w)
 global     noise Pt  ;
 % ---input
 % fun   objective
 % a     
 % b      
 %eps     
 % ---output
 % xmin  
 eps=0.1;%accuracy
 
 x1 = a+0.382*(b-a);
 x2 = a +0.618*(b-a);
 %find f1 f2 
[f1,Q_opt,Du_T3,Du_Q]=Solve_h_u_w(i,j0,u_T3,u_Q,u_f,u_w,x1);
[f2,Q_opt,Du_T3,Du_Q]=Solve_h_u_w(i,j0,u_T3,u_Q,u_f,u_w,x2); 

 while abs(b-a)>eps
     if f1>f2
         a = x1;
         x1 = x2;
         x2 = a +0.618*(b-a);
         f1 = f2;
         %find new f2
          [f2,Q_opt,Du_T3,Du_Q]=Solve_h_u_w(i,j0,u_T3,u_Q,u_f,u_w,x2); 
     else
         b = x2;
         x2 = x1;
         x1 = a+0.382*(b-a);
         f2 = f1;
          %find new f1 
          [f1,Q_opt,Du_T3,Du_Q]=Solve_h_u_w(i,j0,u_T3,u_Q,u_f,u_w,x1); 
     end
 end
 xmin=(b+a)/2; 
fmin=f1;
