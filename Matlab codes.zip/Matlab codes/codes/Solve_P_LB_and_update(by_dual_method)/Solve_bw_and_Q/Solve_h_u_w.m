function [y,y_Q,Du_T3,Du_Q]=Solve_h_u_w(i,j0,u_T3,u_Q,u_f,u_w,w_ij0)
%give u and w, solve h(u,w), return optimum Q and a few subgradients 

global Nt Nr N_user N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up k0  Tmax H  ;
global lambda1 lambda2;

A=u_T3(i)*b_up*L(i)/w_ij0;
C=u_Q(i);
Bx=lambda2*b_up*L(i)/w_ij0; 
y_Q=Solve_Q(A,Bx,C,H(:,:,i,j0)) ; 
r_ij0=real(log2(det(eye(Nt)+ H(:,:,i,j0)'*H(:,:,i,j0)*y_Q/noise)));
E_ij0=real(b_up*L(i)*trace(y_Q)/w_ij0/r_ij0);
T_ij0=a_exe*L(i)/f_MEC/1000 + b_up*L(i)/w_ij0/r_ij0; 

%--------function objective value---------
y=lambda2*E_ij0 + u_T3(i)*(T_ij0-Tmax) + u_Q(i)*(trace(y_Q)-Pt)...
     -u_f(i)*f_Lmax(i) + w_ij0*u_w(j0) ;
 
%----subgradients-----
Du_T3 =(T_ij0-Tmax); 
 Du_Q =real(trace(y_Q)-Pt); 