function [y_LB,y_flag]=Solve_P_LB(xin,level )
%level--denotes which floor the current node locates 
% xin--denotes a few users' choices  
%output��
%flag has 3 states��-1--infeasible��
% 0--feasible, but can not branch or no need to branch 
% 1--feasible, can branch

global Nt Nr N_user N_BS Pt k0 f_Lmax f_MEC B noise L a_exe b_up   Tmax H Emax Rmax Vopt;
global lambda1 lambda2;
global Node_id_cur ;  
%N_user_fix: predetermined users, their choices are put into Xc
%Xc has N_user_fix rows
N_user_fix=level-1;
Xc=zeros(level-1,N_BS+1); 
for i=1:level-1 
    for j=1:N_BS+1
        if j==xin(i)
            Xc(i,j)=1;
        else
            Xc(i,j)=0;
        end
    end
end  

%=============Case I: leaf node=============
if N_user_fix==N_user %leaf node
    y_flag=0; %can not branch
    fprintf('The current node is the leaf node, we user SCA method to calculate its value...\n'); 
    cd ./SCA-Solve-leafnode-M2  
    [Obj_Cal, Qy ,fy ,bwy] = F_actual(Xc,lambda1,lambda2);
    cd ..
    if Obj_Cal<Vopt.v  %update Vopt 
      Vopt.X=Xc;Vopt.v=Obj_Cal;Vopt.Q=Qy;Vopt.bw=bwy;Vopt.f=fy;
      fprintf('current node id:%d,Vopt is updated��Vopt.v=%.3f\n',Node_id_cur,Vopt.v); 
    end
    y_LB=Obj_Cal;
    return;
end

%=============Case II: non-leaf node=============
if N_user_fix<N_user  
 % ---------Step 1:   solve LB----------
step_u=0.1/2; 
%initialize u's
u_T3=0.1+lambda1/N_user*ones(N_user,1); 
u_Q=0.1*ones(N_user,1);
u_f=0.1*ones(N_user,1);
u_w=0.1*ones(N_BS,1);

flag=1;Iter_Max=40;
y0=-100; 
index=0; 
while(flag) 
    index=index+1 ;
    if index==8
        c=0;
    end
%compute g(u)=min L(X,u)
[y_tmp,V_u_tmp,Du_T3,Du_Q,Du_f,Du_w]=Solve_g_u_v2(u_T3,u_Q,u_f,u_w,Xc);  
%update y and y0 
if index>10 
    y(index)=max(y_tmp,y0) ;
else
    y(index)= y_tmp  ;
end
if y_tmp>y0  
    V_u=V_u_tmp;
end
y0=y(index);

 %update u's
 Norm_total=norm([norm(Du_T3) norm(Du_Q)  norm(Du_f) norm(Du_w)]);
 if Norm_total<1e-2 
     flag=0;
 else
    u_T3=max(0,u_T3+step_u*Du_T3/norm(Du_T3));
    u_Q=max(0,u_Q+step_u*Du_Q/norm(Du_Q));
    u_f=max(0,u_f+step_u*Du_f/norm(Du_f));
    u_w=max(0,u_w+step_u*Du_w/norm(Du_w));
 end 
 if sum(u_T3)<lambda1
     u_T3=0.01+lambda1*u_T3/sum(u_T3);
 end 
 if index>Iter_Max|y(end)>20
     flag=0;
 end 
end
y_LB=y(end) ; 

%---Step 2: Determine whether the dual solution is feasible. If yes, consider updating Vopt-----
if y_LB>Vopt.v  
    y_flag=0;
    return;
end 
flag1=feasible_test_X(V_u.X,V_u.Q,V_u.bw,V_u.f);
if flag1==0 
    y_flag=1; 
else %the dual solution is feasible to the orginal problem, and consider to update Vopt
    y_flag=1; 
    [F_obj_tmp, Etmp, Ttmp]=E_T_Cal(V_u.X,V_u.Q,V_u.f,V_u.bw); 
    if abs(y_LB-F_obj_tmp)<1e-5  
        y_flag=0;
    end
    if Vopt.v>F_obj_tmp 
       Vopt.v=F_obj_tmp;
       Vopt.X=V_u.X;Vopt.Q=V_u.Q;Vopt.bw=V_u.bw;Vopt.f=V_u.f;
       fprintf('current node id:%d,Vopt is updated��Vopt.v=%.3f\n',Node_id_cur,Vopt.v); 
    end  
end
end