function [flag_y]=feasible_test_X(X,Q,bw,f)
%given X��Q��f,bw��test the feasibility
global Nt Nr N_user  N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up   Tmax H  ;
  
%--initial judgement-----
for i=1:N_user  
   if trace(Q(:,:,i))>Pt
       flag_y=0;  
       return;
   end 
   if f(i)>f_Lmax
       flag_y=0;  
       return;
   end
end
 
 R_bar=zeros(N_user,N_BS);  
for i=1:N_user
    for j=1:N_BS
        if X(i,j+1)==1
          R_bar(i,j)=X(i,j+1)*log2(det(eye(Nr,Nr) + H(:,:,i,j) * Q(:,:,i) *(H(:,:,i,j))'/noise)) ;
       end
    end 
end

%-------------------test the feasibility by two conditions-------------------------
%Condtion 1��bandwidth
for j=1:N_BS
    if sum(bw(:,j)) > B(j) 
         flag_y=0;  
         return;
    end
end

%condtion 2��latency  
T_user=zeros(N_user,1);  
for i=1:N_user
    if X(i,1)==1
        T_user(i)=  X(i,1)*a_exe*L(i)/(f(i)*1000);
    end
  for j=2:N_BS+1
      if X(i,j)==1
         T_user(i)=T_user(i) + X(i,j)*(b_up*L(i)/bw(i,j-1)/R_bar(i,j-1) + a_exe*L(i)/(f_MEC *1000));
      end
  end
end 
if max(T_user)<=Tmax + 1e-6   
    flag_y=1;
else 
    flag_y=0; 
end  