function [y,V_u,Du_T3_final,Du_Q_final,Du_f_final,Du_w_final] =Solve_g_u_v2(u_T3,u_Q,u_f,u_w,Xc)
%Given Xc, et al., 
%find y--g(u); V_u corresponds to u; the left are subgradients at u 

global Nt Nr N_user N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up k0  Tmax H  ;
global lambda1 lambda2; 

y_obj=1000000; X_opt=[]; V_u=[]; 
Du_T3_final=[]; Du_Q_final=[]; Du_f_final=[];Du_w_final=[];
[ar bc]=size(Xc); 
Iter_Max=(N_BS+1)^(N_user-ar);
xin=ones(N_user-ar,1); 
flag=1;
index=0;
rand('seed',0);
while(flag) 
    index=index+1 ;
%---1 generate an X ----
X=zeros(N_user,N_BS+1);
%1.1 assign X's a few first rows to be Xc 
X(1:ar,:)=Xc; 
%1.2 generate user choice vector xin(.)
if index>1
    for i=1:N_user-ar
            xin(i)=xin(i)+1;
            if xin(i)>N_BS+1
                xin(i)=1;
            else
                break;
            end
    end 
end
 %1.3 use xin  to generate Xc2
 Xc2=zeros(N_user-ar,N_BS+1); 
for i=1:N_user-ar 
    for j=1:N_BS+1
        if j==xin(i)
            Xc2(i,j)=1;
        else
            Xc2(i,j)=0;
        end
    end
end
%1.4 ƴ��
X(ar+1:end,:)=Xc2;
%------end 1-------------

%----2 initialize f_opt,Q_opt,w_opt  et al.------------
f_opt=zeros(N_user,1);  
Du_f=zeros(N_user,1); 
Du_T3=zeros(N_user,1); 
for i=1:N_user  
   Q_opt(:,:,i)=zeros(Nt,Nt);
   Du_Q(i,1)=0;
end
for i=1:N_user  
    for j=1:N_BS
      w_opt(i,j)=0; 
      Du_w(j,1)=0;
    end
end

%----solve h_obj(i),i=1...N_user-----
for i=1:N_user
    if X(i,1)==1
        A=u_T3(i)*a_exe*L(i)/1000;
        Bx=2*k0*1e6*a_exe*L(i)*lambda2;
        if Bx>0
        tmp=Solve3Polynomial(1, u_f(i)/Bx, 0, -A/Bx);
        f_opt(i)=max(real(tmp));
        else
            f_opt(i)=sqrt(A/u_f(i));
        end
        Q_opt(:,:,i)=zeros(Nt,Nt); 
        %--solve a special case: u_T3(i)=0--
        if f_opt(i)>0
            Ti0=a_exe*L(i)/f_opt(i)/1000;
        else
            Ti0=1000; 
        end
        Ei0=k0*1e6*f_opt(i)^2*a_exe*L(i);
        h_obj(i)=lambda2*Ei0 + u_T3(i)*(Ti0-Tmax) + u_f(i)*(f_opt(i)-f_Lmax(i)) +...
            u_Q(i)*(trace(Q_opt(:,:,i))-Pt);
        Du_T3(i)=(Ti0-Tmax); Du_f(i)=f_opt(i)-f_Lmax(i); Du_Q(i,1)=-Pt;
    else 
        %Step 1 find the index=1 to denote the BS id-->j0
        tmp_x=X(i,:);
        [tmp,j0]=max(tmp_x);
        j0=j0-1;
        %----solve a special case: u_w(j0)=0---
        if u_w(j0)<1e-8 
            %a Opt solution
            w_opt(i,j0)=10000;%should be Inf
            Q_opt(:,:,i)=zeros(Nt,Nt);f_opt(i)=0;
            E_ij0=0;T_ij0=0;
            %b opt objective
            h_obj(i)= lambda2*E_ij0 + u_T3(i)*(T_ij0-Tmax) + u_f(i)*(f_opt(i)-f_Lmax(i)) +...
            u_Q(i)*(trace(Q_opt(:,:,i))-Pt) + w_opt(i,j0)*u_w(j0);
            %c subgradients
            Du_T3(i)=-Tmax;Du_Q(i)=-Pt; Du_f(i)=-f_Lmax(i);
            continue;
        end
        %-----end special case----
        %Step 1  1D search for w_ij0 
        %Goldsection search
        bw_l = 0.1; bw_r =  B(j)*5;
        cd .\Solve_bw_and_Q
        [hy_min,bw_min,Q_opt(:,:,i),Du_T3(i),Du_Q(i)] = goldSearch_bw(bw_l,bw_r,i,j0,u_T3,u_Q,u_f,u_w); 
        cd ..
        h_obj(i)=hy_min;
        w_opt(i,j0)=bw_min;
        Du_f(i)=-f_Lmax(i);
    end%X(i,1)
end%i
Du_w =(sum(w_opt,1)).'-B; 

 %-----3 solve sum h_obj(i) ----
 h_X=sum(h_obj) ;
 
 %----4 judge whether h_X is smaller��update Q,f,w, et al.----
%  tackle the NaN case
if (h_X>0|h_X <=0 )==0
    h_X=Inf;
end
 if y_obj>h_X
     y_obj=h_X;
     X_opt=X;  
     V_u.X=X_opt;    V_u.f=f_opt;      
     V_u.bw=w_opt;   V_u.Q=Q_opt;  
     Du_T3_final=Du_T3;     Du_f_final=Du_f;
     Du_Q_final=Du_Q;       Du_w_final=Du_w;
 end 
 
 %---5 while judgement-------
 if index>=Iter_Max
     flag=0;
 end 
end
 
%----result-----
Cst=(1-lambda2)*Tmax-sum(B.*u_w);
y=y_obj+Cst;
        
