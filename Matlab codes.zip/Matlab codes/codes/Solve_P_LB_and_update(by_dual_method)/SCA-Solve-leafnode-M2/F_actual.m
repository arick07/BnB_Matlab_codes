function [Obj_Cal, Qy ,fy ,bwy]=F_actual(X,lambda1,lambda2)
global Nt Nr N_user N_BS  k0 a_exe L b_up f_MEC H noise;

% intialize a point�� 
 [Q,f,bw,flag_r]=feasible_gen_X(X);%method 1
if flag_r==0%infeasible
    Obj_Cal=Inf;  Qy=[]; fy=[];bwy=[]; return;
end 

%------if feasible-------
%1.1 compute r_bar
for i=1:N_user
    for j=1:N_BS
        r_bar(i,j) = real(log2(det(eye(Nr,Nr) + H(:,:,i,j)*Q(:,:,i)*(H(:,:,i,j))'/noise)));  
    end
end 
%1.2 compute T_sys��T_i��t_up_bar
T_bar=zeros(N_user,N_BS+1); E_bar=zeros(N_user,N_BS+1);
t_up_bar=zeros(N_user,1);
Y.Q=Q;Y.bw=bw;Y.f=f; 
T_user=zeros(N_user,1);
for i=1:N_user
     [tmp,j0]=max(X(i,:)); j0=j0-1;
     if j0==0 %local 
        T_user(i)=a_exe*L(i) * X(i,1) /(Y.f(i) * 1000);  
     else%j0>=1   %MEC
          t_up_bar(i) = b_up* L(i)/r_bar(i,j0)/Y.bw(i,j0); %offloading time 
          T_user(i) = t_up_bar(i)+a_exe *L(i)/(f_MEC*1000);%offloading time +MEC execution time
     end
end
Y.T_i=T_user; 
Y.T_sys=max(T_user);
Y.t_up_bar=t_up_bar;   

%==========Begin============
clear   Q f bw;
clear  t_up_bar T_user  ;%clear
r=1;%step size
epsilon=0.001 ;%step factor
threshold=1e-3;Iter_Max=30;
Obj_pre=1000;F_obj_pre=1000; 
Q_pre=[];bw_pre=[];f_pre=[];
index=0; flag=1;
while(flag)
    index=index+1;
[Obj_current, Y_new,flag_r]=solve_P_CVX(X,lambda1,lambda2,Y);  
    [F_obj, E, T]=E_T_Cal(X,Y_new.Q,Y_new.f,Y_new.bw); 
%stop condition and updation 
%stop condition
norm_Q=0;
tmp= norm(Y_new.bw-Y.bw,'fro') +norm(Y_new.f-Y.f) ;
tmp=tmp+abs(Y_new.T_sys-Y.T_sys)+norm(Y_new.T_i-Y.T_i) +norm(Y_new.t_up_bar-Y.t_up_bar) ;
for i=1:N_user
    tmp=tmp+norm(Y_new.Q(:,:,i)-Y.Q(:,:,i)) ;
    norm_Q=norm_Q+norm(Y_new.Q(:,:,i));
end
tmp=tmp/(norm(Y_new.bw,'fro')+norm_Q+norm(Y_new.f)+...
    abs(Y_new.T_sys)+norm(Y_new.t_up_bar)+norm(Y_new.T_i));
 
if tmp<threshold || flag_r==0  ||  index>Iter_Max ||(F_obj>F_obj_pre && index>2)
    flag=0;
else  %update Y, Obj_pre et al.
    %1 Key parameters updating 
    Y.Q = Y.Q+r*(Y_new.Q-Y.Q);
    Y.f = Y.f+r*(Y_new.f-Y.f);
    Y.bw =Y.bw+r*(Y_new.bw-Y.bw);
    %2 auxialiary parameters updating
    Y.T_sys=Y.T_sys+r*(Y_new.T_sys-Y.T_sys);
    Y.T_i=Y.T_i+r*(Y_new.T_i-Y.T_i);
    Y.t_up_bar=Y.t_up_bar+r*(Y_new.t_up_bar-Y.t_up_bar); 
    %3 Step size r, objective value, and Xopt
    r=r*(1-epsilon*r) ;
    if flag_r==1 
       Obj_pre=Obj_current;  
       F_obj_pre=F_obj; 
       Q_pre=Y_new.Q;
       bw_pre=Y_new.bw;
       f_pre=Y_new.f;
    end
end%if
end%while 
  
Obj_Cal=F_obj_pre; 
Qy=Q_pre;bwy=bw_pre;fy=f_pre; 