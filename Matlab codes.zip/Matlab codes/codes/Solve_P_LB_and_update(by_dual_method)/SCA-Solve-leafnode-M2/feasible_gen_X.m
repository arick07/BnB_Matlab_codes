function [Q,f,bw,flag_y]=feasible_gen_X(X)
%Given X, generate a feasible point
% Q--Waterfilling OPT, min bandwidth, max f=f_Lmax 
global Nt Nr N_user N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up   Tmax H  ; 
 R_bar=zeros(N_user,N_BS);
 bw_Min=zeros(N_user,N_BS);
for i=1:N_user
    %      Q(:,:,i)=Pt/Nt*eye(Nt,Nt);
       Q(:,:,i)=zeros(Nt,Nt);
    for j=1:N_BS 
       if X(i,j+1)==1 
           Q(:,:,i)=water_fill_Qopt(H(:,:,i,j),Pt,noise);
       end
    end
end
for i=1:N_user
    for j=1:N_BS
        if X(i,j+1)==1
          R_bar(i,j)=X(i,j+1)*real(log2(det(eye(Nr,Nr) + H(:,:,i,j) * Q(:,:,i) *(H(:,:,i,j))'/noise))) ;
          bw_Min(i,j)=X(i,j+1)*b_up*L(i)/R_bar(i,j)/(Tmax-a_exe*L(i)/(f_MEC *1000)); 
        end
    end 
end
for j=1:N_BS
    if sum(bw_Min(:,j)) > B(j)
         fprintf('%d BS bandwidth is not enough, infeasible��\n',j);
         flag_y=0;f=0;bw=[];
         return;
    end
end

%-------otherwise feasible-------------
f=f_Lmax; 
bw=zeros(N_user,N_BS);  
T_user=zeros(N_user,1); 

%1  generate bw
 bw = bw_Min;  
%2 compute each user's latency  
for i=1:N_user
    T_user(i)=  X(i,1)*a_exe*L(i)/(f(i)*1000);
  for j=2:N_BS+1
      if X(i,j)==1
         T_user(i)=T_user(i)+X(i,j)*( b_up*L(i)/bw(i,j-1)/R_bar(i,j-1) + a_exe*L(i)/(f_MEC *1000));
      end
  end
end
%3 judgement
if max(T_user)<=Tmax + 1e-6  
%     fprintf('Given X��we have found a feasible solution\n');  
    flag_y=1;
else
%     disp('Given X, the problem is infeasible��');
    flag_y=0;f=0;bw=[]; 
end 
 
