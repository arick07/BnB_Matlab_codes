function [Obj_F,Y_new,flag]=solve_P_CVX(X,lambda1,lambda2,Y)%���͹��������
%this is the paper version, where both w and Q are linearized
%Solve P��(given X, d, where d is a feasible point)
% P: min F=lambda1*E_total+lambda2*T_sys
% s.t. C1: T_sys<=Tmax; %latency constraint 
% flag=1 --feasible��0 -- infeasible
 global Nt Nr N_user N_BS Pt k0 f_Lmax f_MEC B noise L a_exe b_up   Tmax H Emax Rmax;

%1  parameters assignment
 Q_y=Y.Q; f_y=Y.f ; bw_y=Y.bw;  
 t_up_bar_y=Y.t_up_bar;        T_i_y=Y.T_i; 
 T_sys_y=Y.T_sys; 
 
%2 compute d1
d1=zeros(N_user,N_BS);  
for i=1:N_user
    [tmp,j0]=max(X(i,:)); j0=j0-1;
     if j0>0 
        d1(i,j0)=bw_y(i,j0)/t_up_bar_y(i); 
     end 
end
%3 compute two derivatives
Dw=zeros(N_user,1); DQ=zeros(Nt,Nt,N_user);
for i=1:N_user
    [tmp,j0]=max(X(i,:)); j0=j0-1;
    if j0>0
        r_tmp = real( log2(det(eye(Nr,Nr) + H(:,:,i,j0)*Q_y(:,:,i)*(H(:,:,i,j0))'/noise) ));  
        Dw(i)=-real(b_up*L(i)*trace(Q_y(:,:,i))/bw_y(i,j0)^2/r_tmp);
        
        M_tmp=inv(eye(Nt)+(H(:,:,i,j0))'*H(:,:,i,j0)*Q_y(:,:,i)/noise);
        DQ(:,:,i)=eye(Nt)*r_tmp-trace(Q_y(:,:,i))/log(2)*M_tmp*(H(:,:,i,j0))'*H(:,:,i,j0)/noise;
        DQ(:,:,i)=DQ(:,:,i)  * b_up*L(i)/bw_y(i,j0)/r_tmp^2;
    end
end
    
 cvx_begin       quiet 
variables Q(Nt,Nt,N_user)   hemitian;
variables f(N_user,1)  bw(N_user,N_BS); %Q--transmission covariance matrix;  f--local computing frequency;  bw--bandwidth allocated to users
variables  t_up_bar(N_user,1)  T_i(N_user,1)    T_sys;
expressions E_total F  F_del   r_bar(N_user,1);
E_total=0;
for i=1:N_user
    [tmp,j0]=max(X(i,:)); j0=j0-1;
    if j0==0
        E_total= E_total + k0*a_exe*L(i)*1e6*  X(i,1)*(f(i))^2 ;
    else
        E_total= E_total + Dw(i)*(bw(i,j0)-bw_y(i,j0)) + ...
            real(trace(DQ(:,:,i)*(Q(:,:,i)-Q_y(:,:,i))));
    end
end 
F_del =square_pos(T_sys-T_sys_y)+ square_pos(norm(t_up_bar-t_up_bar_y,'fro')) + square_pos(norm(T_i-T_i_y,'fro'))...
    + square_pos(norm(bw-bw_y,'fro'));
for i=1:N_user
     F_del=F_del+square_pos(norm(Q(:,:,i)-Q_y(:,:,i),'fro'));
end
F = lambda1* T_sys+ lambda2 * E_total + 0.01*F_del; %F_del is strongly convex

for i=1:N_user
  [tmp,j0]=max(X(i,:));
  j0=j0-1;
  if j0>=1
    r_bar(i) = real( log_det(eye(Nr,Nr) + H(:,:,i,j0)*Q(:,:,i)*(H(:,:,i,j0))'/noise)/log(2) );  
  else
    r_bar(i)=0;
  end
end

minimize F
subject to
%1 latency constraint
for i=1:N_user  
  T_i(i) <=T_sys;  %C1-1
  T_i(i) <=Tmax;  %C1-2
end
for i=1:N_user
   [tmp,j0]=max(X(i,:));j0=j0-1; 
  if j0==0
     t_up_bar(i)==0; 
    T_i(i) >= a_exe*L(i)*pow_p(f(i),-1) /1000;%C1-3a
  else 
    t_up_bar(i)>=0;
    T_i(i) >= t_up_bar(i)+ a_exe*L(i)/(f_MEC*1000); %C1-3a
  end  
end
% variable substitution: C1-3b 
for i=1:N_user
    [tmp,j0]=max(X(i,:));j0=j0-1; 
    if j0>0 
 %    b_up *  L(i)*X(i,j0)/t_up_bar(i)/bw(i,j0-1) <= r_bar(i,j0-1);  ��1��
        %--> C1 changes to
        b_up *  L(i) *1/2*(d1(i,j0)*pow_p(bw(i,j0),-2) +1/d1(i,j0)*pow_p(t_up_bar(i),-2)) <= r_bar(i); 
    end   
end

%2 bandwidth constraint
for i=1:N_user
    [tmp,j0]=max(X(i,:));j0=j0-1;  
    for j=1:N_BS
        if j==j0
          bw(i,j)>=0;
        else
          bw(i,j)==0;  
        end
    end 
end
for j=1:N_BS    
    sum(bw(:,j)) <= B(j);
end
%3 transmission power constraint
for i=1:N_user
    if X(i,1)==1%local
        Q(:,:,i)==zeros(Nt,Nt);
    else
       trace(Q(:,:,i))<=Pt;
        Q(:,:,i) == hermitian_semidefinite(Nt);
    end
end
%4  local computation frequency constraint
for i=1:N_user
   f(i)<=f_Lmax(i);
   f(i)>=0;
   if X(i,1)==0
       f(i)==0;
   end
end 
cvx_end
%-----------result-------------
Obj_F=cvx_optval; 
% F
% cvx_optval
Y_new.Q=Q;
Y_new.f=f;
Y_new.bw=bw; 
Y_new.t_up_bar=t_up_bar;
Y_new.T_i=T_i;
Y_new.T_sys=T_sys;

if cvx_optval==Inf%infeasible
    flag=0;
else
    flag=1;
end

tmp=(Obj_F>1|Obj_F<=1);%tackle the NaN case
if tmp==0
    flag=0;
end