function [F_obj, E, T] = E_T_Cal(X,Q,f,bw)
global Nt Nr N_user N_BS    k0  f_MEC   noise L a_exe b_up    H  lambda1 lambda2;
T_user=zeros(1,N_user);
    E_user=zeros(1,N_user);
    for i=1:N_user
      for j=1:N_BS
        R_bar(i,j) = log2(det(eye(Nr,Nr) + H(:,:,i,j)*Q(:,:,i)*(H(:,:,i,j))'/noise));  
      end
    end
    for i=1:N_user
        if X(i,1)==1
          T_user(i)=  X(i,1)*a_exe*L(i)/(f(i)*1000);
          E_user(i)= X(i,1)*k0*a_exe*L(i)*(f(i)*1000)^2;
        end
        for j=2:N_BS+1
           if X(i,j)==1
              T_user(i)=T_user(i) + X(i,j)*(b_up*L(i)/bw(i,j-1)/R_bar(i,j-1)  + a_exe *L(i)/(f_MEC *1000));
              E_user(i)=E_user(i) + X(i,j)*trace(Q(:,:,i))*b_up* L(i)/bw(i,j-1)/R_bar(i,j-1);
          end
        end
    end
    T=max(T_user);
    E=sum(E_user);
    F_obj=lambda1*T+lambda2*E;