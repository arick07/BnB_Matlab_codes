clear all;close all;clc; 
global Nt Nr N_user N_BS Pt k0  f_MEC   B noise  a_exe b_up  Tmax  Emax Rmax ;
global L f_Lmax H lambda1 lambda2;
global Node_id_cur Vopt node;  

%==========System parameters==========
%----initialize Vopt and node----
Vopt.v=10000;Vopt.X=[];Vopt.Q=[];Vopt.f=[];Vopt.bw=[];
for i=1:1000
node(i).father=-1;node(i).level=1;
node(i).x=[];  node(1).status=-3;    node(1).LB=Inf;
end 
%-----N_user, N_BS, Nt=Nr--- 
N_user=3; %user number
N_BS=2;  %BS number
Nt=2;Nr=Nt; %antenna number
%--------Powers et al.-------- 
%User maximum transmission power 
Pt= 1;%W
%for Local compute
k0=1e-28*1e18;%unit: J/MHz^2/Mbit  
f_MEC=12;%MEC calculation frequency  unit:  GHz
noise=25e-13;%noise power  unit:  W
W=20;  %each BS bandwidth  unit: MHz
B=W*ones(N_BS,1);% all BS's bandwidths
Tmax=1;%maximum latency tolorancy, unit: s
%------User data factors-------- 
a_exe=40;%Local/MEC: task execution factor 
b_up=1.2;%MEC: task overhead factor 
%-----two weights--------
lambda1=0.5;%for time
lambda2=1-lambda1;%for energy 

fid1=fopen('result_H.txt','a+'); 
X=zeros(N_user,N_BS+1);%task association matrix
H_samp=20;%number of channel samples  
H_index=0;
for H_i=1:H_samp %H_i: Channel id
    H_index=H_index+1;
    %S1: ----For each H, set L and f_Lmax repeatedly, to avoid possilbe error afer H_gen()--- 
    rand('seed',0);
    L=5+round(rand(N_user,1)*10);%task size, unit��M bit 
    rand('seed',1);
    f_Lmax=0.5+1*rand(N_user,1);%Maxitmu local computing frequency, unit: GHz   
    %S2: ----Generate a channel sample----- 
    cd .\Channel_generate 
       H_gen_v2('M2','descend',H_i); 
    cd ..
    %S3: ----Compute Emax and Rmax----
    Emax=Pt*Tmax;%Maximum energy consumption
    % Q=Pt/Nt*eye(Nt,Nt);
    for i=1:N_user
        for j=1:N_BS
            Q=water_fill_Qopt(H(:,:,i,j),Pt,noise);
            R_bar(i,j)=real(log2(det(eye(Nr,Nr) + (H(:,:,i,j))'*H(:,:,i,j) * Q/noise))) ;
         end
    end
    Rmax=max(max(R_bar)); 
    %S4: ----Procedure formly starts------
    if H_index==1 
       fprintf(fid1, '\n=====Procedure begins=====\n');
       fprintf(fid1,'System settings��user %d,BS %d,antenna %d*%d,\n',N_user,N_BS,Nr,Nt);
    end 
    [node_num]=Branch_bound_with_dual_LB(H_i,lambda1,lambda2);
    [F_obj(N_user,H_i), E(N_user,H_i), T(N_user,H_i)]=E_T_Cal(Vopt.X,Vopt.Q,Vopt.f,Vopt.bw);  
    fprintf(fid1,'===channel id:%d,lambda1=%.2f,lambda2=%.2f, Vopt: %.4f, T=%.4f, E= %.4f===\n',...
        H_i,lambda1,lambda2,Vopt.v,T(N_user,H_i),E(N_user,H_i)); 
end % for_H_i    
fclose(fid1); 