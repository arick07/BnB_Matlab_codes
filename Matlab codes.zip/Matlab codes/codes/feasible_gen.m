function [X,Q,f,bw,flag_y]=feasible_gen()
% generate a feasible solution (via the proposed heuristic algorithm��  
global Nt Nr N_user N_BS Pt   f_Lmax f_MEC B noise L a_exe b_up   Tmax H  ;

% preprocessing
 R_bar=zeros(N_user,N_BS);
 bw_Min=zeros(N_user,N_BS); 
%1  find Qopt
for i=1:N_user 
    for j=1:N_BS
       Qopt(:,:,i,j)=water_fill_Qopt(H(:,:,i,j),Pt,noise);
    end
end 
%2 find R_bar
for i=1:N_user
    for j=1:N_BS
       R_bar(i,j) = log2(det(eye(Nr,Nr) + H(:,:,i,j) * Qopt(:,:,i,j) *(H(:,:,i,j))'/noise)) ;
    end
end
%3  find bw_Min
for i=1:N_user
    for j=1:N_BS 
          bw_Min(i,j)=b_up*L(i)/R_bar(i,j)/(Tmax-a_exe*L(i)/(f_MEC *1000)); 
    end 
end 
 
%----------begin---------- 
bw=zeros(N_user,N_BS); 
flag_out=1;k=1;Kmax=10000;
rand('seed',0);
while(flag_out)
    k=k+1; 
%a generate the association matrix X
X=zeros(N_user,N_BS+1);
for i=1:N_user 
    tmp=rand(1,N_BS+1);
    [a b]=max(tmp);
    X(i,b)=1; 
end 
%b judge whether X is feasible
flag1=1;
  for i=1:N_user
      if X(i,1)==1
          if a_exe*L(i)/f_Lmax(i)/1000<=Tmax
              f(i)=f_Lmax(i);Q(:,:,i)=zeros(Nt,Nt);bw(i,:)=0;
          else
              flag1=0;
              break; 
          end
      end
       for j=2:N_BS+1
           if X(i,j)==1
               tmp2=sum(X(:,j).* bw_Min(:,j-1)); 
               if tmp2<=B(j-1)
                  Q(:,:,i)= Qopt(:,:,i,j-1);f(i)=0;bw(i,j-1)=bw_Min(i,j-1);
               else
                 flag1=0;
                 break; 
               end
           end
       end
       if flag1==0 
           break; 
       end
  end
 %c  determine whether the while-loop  can end   
  if flag1==1
      flag_out=0;flag_y=1;
      fprintf('k=%d, find a feasible solution\n',k);
  end 
 if k>=Kmax
     flag_out=0;
     fprintf('Exceed the maximum times %d��can not find a feasible solution\n',Kmax);
     disp(X);
     flag_y=0;
     return;
 end
end
X