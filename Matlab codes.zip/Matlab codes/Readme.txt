                     
                     Operation instruction
                     
Step 1: Enter the directory ��cvx-version 2.0��, run cvx_setup.m.
Step 2: Enter the directory ��codes��, run main.m.
Step 3: Enter the directory ��codes��, obtain the result by opening "result_H.txt".          


 